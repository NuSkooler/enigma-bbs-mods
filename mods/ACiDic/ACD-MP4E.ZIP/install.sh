#!/usr/bin/env bash

ENIG_DIR=$1
ENIG_MODS=$ENIG_DIR/mods

if [ -d "$ENIG_MODS" ]; then
	mkdir "$ENIG_MODS/message_post_evt"
	cp message_post_evt.js "$ENIG_MODS/message_post_evt/"
	cp package.json "$ENIG_MODS/message_post_evt/"
else
	echo "$ENIG_MODS does not exist"
fi
