#!/usr/bin/env bash

ENIG_DIR=$1
ENIG_MODS=$ENIG_DIR/mods

if [ -d "$ENIG_MODS" ]; then
	mkdir "$ENIG_MODS/married_bob_evt"
	cp married_bob_evt.js "$ENIG_MODS/married_bob_evt/"
	cp package.json "$ENIG_MODS/married_bob_evt/"
	cd "$ENIG_MODS/married_bob_evt"
	mkdir cache
	npm install
else
	echo "$ENIG_MODS does not exist"
fi
