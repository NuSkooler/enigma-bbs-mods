#!/usr/bin/env node

const argv = require('minimist')(process.argv.slice(2), {
    alias: {
        h: 'help',
        v: 'version',
        f: 'filename',
        H: 'hash',
        y: 'no-prompt',
        d: 'db-only',
    },
});

const config = require('../../core/config');
const db = require('../../core/database');
const { splitTextAtTerms, isAnsi } = require('../../core/string_util');
const AnsiPrep = require('../../core/ansi_prep');

const async = require('async');
const _ = require('lodash');
const inq = require('inquirer');

const displayVersion = () => {
    const version = require('./package.json').version;
    console.info(version);
    process.exit();
};

const displayHelp = () => {
    const help = `Phenom Productions
dupeNuke! for ENiGMA½ BBS Sofware by NuSkooler - Copyright (c) 2022 Phenom Productions

Scan for and eliminate duplicate file base entries found within
your your ENiGMA½ system!

USAGE:
    dupenuke [OPTIONS]

OPTIONS:
    -h, --help        Display this help
    -v, --version     Display version and exit
    -f, --filename    Include duplicates found by case-insensitive filename matches
    -H, --hash        Include duplicates found by exact SHA-256 match
                      Note that in general ENiGMA attempts to avoid this scenario,
                      and as such, this is much less common, if at all in most systems
    --area-tag        Specify a area tag to scan. Additional areas may be supplied
                      by repeating the option
    -y, --no-prompt   Assume yes to all queries; Attempt to proceed without prompting
    -d, --db-only     Only remove from database, leaving physical files intact
`;
    console.info(help);
    process.exit();
};

// defaults
let withHash = false;
let withFileName = true;
let dbOnly = false;
let noPrompt = false;

const init = () => {
    return new Promise((resolve, reject) => {
        async.series(
            [
                callback => {
                    let configPath = '../../config/config.hjson';

                    const configOpts = { keepWsc: true, hotReload: false };

                    return config.Config.create(configPath, configOpts, err => {
                        if (err) {
                            // try alternative
                            configPath = './config/config.hjson';
                            return config.Config.create(configPath, configOpts, callback);
                        }
                        return callback(null);
                    });
                },
                callback => {
                    return db.initializeDatabases(callback);
                },
            ],
            err => {
                return err ? reject(err) : resolve();
            }
        );
    });
};

const getDuplicates = (fileEntry, fileId) => {
    return new Promise((resolve, reject) => {
        fileEntry.loadBasicEntry(fileId, null, (err, basicEntry) => {
            if (err) {
                return reject(err);
            }

            async.waterfall(
                [
                    callback => {
                        if (!withHash) {
                            return callback(null, []);
                        }

                        fileEntry.getFileIdsBySha(
                            basicEntry.fileSha256,
                            {
                                // no opts
                            },
                            (err, fileIds) => {
                                if (err) {
                                    return callback(err);
                                }

                                return callback(
                                    null,
                                    fileIds.filter(fid => fid != fileId)
                                );
                            }
                        );
                    },
                    (dupeFileIdsHash, callback) => {
                        if (!withFileName) {
                            return callback(null, dupeFileIdsHash);
                        }

                        const filter = {
                            fileName: basicEntry.fileName,
                            filenameCaseSensitive: false,
                        };

                        fileEntry.findFiles(filter, (err, fileIds) => {
                            if (err) {
                                return callback(err);
                            }

                            return callback(
                                null,
                                dupeFileIdsHash.concat(
                                    fileIds.filter(fid => fid != fileId)
                                )
                            );
                        });
                    },
                ],
                (err, dupeFileIds) => {
                    return err ? reject() : resolve(dupeFileIds);
                }
            );
        });
    });
};

const collectDuplicateInfo = areaTags => {
    return new Promise((resolve, reject) => {
        init().then(() => {
            const { getAvailableFileAreaTags } = require('../../core/file_base_area');

            const FileEntry = require('../../core/file_entry');

            const entries = new Map();

            if (_.isString(areaTags)) {
                areaTags = [areaTags];
            } else if (!Array.isArray(areaTags)) {
                areaTags = getAvailableFileAreaTags(null, {
                    skipAcsCheck: true,
                });
            }

            const entryExists = fileId => {
                if (entries.has(fileId)) {
                    return true;
                }
                for (const fid of entries.entries()) {
                    if (fid === fileId) {
                        return true;
                    }
                }
                return false;
            };

            // If we grab all areas at once, we could have a HUGE list of file IDs
            // so instead, process one area at a time.
            async.eachSeries(
                areaTags,
                (areaTag, nextAreaTag) => {
                    FileEntry.findFiles({ areaTag }, (err, fileIds) => {
                        if (err) {
                            return nextAreaTag(err);
                        }

                        process.stdout.write(
                            `Scanning ${fileIds.length} file(s) in ${areaTag}...`
                        );

                        // Have an array of IDs. For each one, start searching dupes
                        let count = 0;
                        let dupeCount = 0;
                        async.eachSeries(
                            fileIds,
                            (fileId, nextFileId) => {
                                if (count++ % 20 === 0) {
                                    process.stdout.write('.');
                                }

                                // Avoid IO if possible
                                if (entryExists(fileId)) {
                                    return nextFileId(null);
                                }

                                getDuplicates(FileEntry, fileId)
                                    .catch(e => {
                                        return nextFileId(e);
                                    })
                                    .then(dupes => {
                                        // drop any new file IDs that are
                                        // already tracked
                                        dupes = dupes.filter(fid => !entryExists(fid));

                                        if (dupes.length > 0) {
                                            dupeCount += dupes.length;
                                            entries.set(fileId, dupes);
                                        }

                                        return nextFileId(null);
                                    });
                            },
                            err => {
                                if (dupeCount > 0) {
                                    console.info(` ${dupeCount} found!`);
                                } else {
                                    console.info('');
                                }
                                return nextAreaTag(err);
                            }
                        );
                    });
                },
                err => {
                    return err ? reject(err) : resolve(entries);
                }
            );
        });
    });
};

const TOP_ACTION_CHOICES = [
    {
        key: 'y',
        name: 'Yes',
        value: 'yes',
    },
    {
        key: 'n',
        name: 'No',
        value: 'no',
    },
    {
        key: 'c',
        name: 'Choose which entry(s) to remove',
        value: 'choose',
    },
    {
        key: 'd',
        name: 'Display dupe information',
        value: 'display',
    },
    new inq.Separator(),
    {
        key: 'x',
        name: 'Abort',
        value: 'abort',
    },
];

const prepShortDesc = (desc, cb) => {
    if (isAnsi(desc)) {
        AnsiPrep(
            desc,
            {
                cols: 79,
                forceLineTerm: true, //  ensure each line is term'd
                asciiMode: process.env.NO_COLOR ? true : false,
                fillLines: false, //  don't fill up to |cols|
            },
            (err, prepped) => {
                return cb(null, (prepped || desc).trimEnd());
            }
        );
    } else {
        // sanatize for the term
        return cb(null, splitTextAtTerms(desc).join('\n').trimEnd());
    }
};

const chooseDupes = (dupes, cb) => {
    inq.prompt({
        name: 'choices',
        message: 'Choose which entry(s) to remove:',
        type: 'checkbox',
        choices: dupes.map(d => {
            return {
                name: `"${d.fileName}", #${d.fileId} in "${d.areaTag}"`,
                value: d.fileId,
            };
        }),
    }).then(choices => {
        return cb(null, choices);
    });
};

const removeEntries = (entryIds, cb) => {
    const FileEntry = require('../../core/file_entry');

    async.eachSeries(
        entryIds,
        (entryId, nextEntry) => {
            const fileEntry = new FileEntry();
            fileEntry.load(entryId, err => {
                if (err) {
                    return nextEntry(err);
                }

                console.info(`Removing #${entryId}: ${fileEntry.fileName}...`);
                FileEntry.removeEntry(fileEntry, { removePhysFile: !dbOnly }, nextEntry);
            });
        },
        err => {
            if (err) {
                console.error(err);
            }
            return cb(err);
        }
    );
};

const processDuplicateEntries = async (fileId, dupeFileIds) => {
    return new Promise((resolve, reject) => {
        const FileEntry = require('../../core/file_entry');
        const { getAreaStorageDirectoryByTag } = require('../../core/file_base_area');

        const showBasicInfo = e => {
            console.info(
                `${e.meta.byte_size} bytes, in ${getAreaStorageDirectoryByTag(
                    e.storageTag
                )}`
            );
            console.info(`SHA-256: ${e.fileSha256}`);
        };

        async.waterfall(
            [
                callback => {
                    // load all the info
                    async.map(
                        [fileId, ...dupeFileIds],
                        (fid, nextFileId) => {
                            const entry = new FileEntry();
                            entry.load(fid, err => {
                                if (err) {
                                    return nextFileId(err);
                                }
                                prepShortDesc(entry.desc, (err, desc) => {
                                    entry.desc = desc;
                                    return nextFileId(null, entry);
                                });
                            });
                        },
                        (err, entries) => {
                            return callback(err, entries);
                        }
                    );
                },
                (entries, callback) => {
                    const master = entries[0];
                    const dupes = entries.slice(1);

                    console.info(
                        `${dupes.length} duplicate(s) found for "${master.fileName}", #${master.fileId} in "${master.areaTag}"`
                    );

                    async.eachSeries(
                        dupes,
                        (entry, nextEntry) => {
                            if (noPrompt) {
                                return removeEntries([entry.fileId], nextEntry);
                            }

                            const promptAgain = () => {
                                inq.prompt({
                                    name: 'action',
                                    message: `Remove # ${entry.fileId} "${entry.fileName}"?`,
                                    type: 'expand',
                                    choices: TOP_ACTION_CHOICES,
                                }).then(answers => {
                                    switch (answers.action) {
                                        case 'yes':
                                            return removeEntries(
                                                [entry.fileId],
                                                nextEntry
                                            );

                                        case 'no':
                                            return nextEntry(null);

                                        case 'display':
                                            console.info(
                                                `Duplicate information for "${master.fileName}", #${master.fileId} in "${master.areaTag}":`
                                            );
                                            console.info(`${master.desc}`);
                                            showBasicInfo(master);
                                            console.info('----');
                                            console.info(
                                                `Duplicate - "${entry.fileName}", #${entry.fileId} in "${entry.areaTag}":`
                                            );
                                            console.info(`${entry.desc}`);
                                            showBasicInfo(entry);
                                            return promptAgain();

                                        case 'choose':
                                            return chooseDupes(
                                                [master, ...dupes],
                                                (err, choices) => {
                                                    if (
                                                        !Array.isArray(choices.choices) ||
                                                        choices.choices.length === 0
                                                    ) {
                                                        return promptAgain();
                                                    }

                                                    return removeEntries(
                                                        choices.choices,
                                                        nextEntry
                                                    );
                                                }
                                            );
                                    }
                                });
                            };

                            promptAgain();
                        },
                        err => {
                            return callback(null);
                        }
                    );
                },
            ],
            err => {
                return err ? reject(err) : resolve();
            }
        );
    });
};

const setRunFromDir = () => {
    const fs = require('fs');
    const paths = require('path');

    let runFromPath = process.argv[1];
    try {
        runFromPath = paths.dirname(fs.readlinkSync(runFromPath));
        process.chdir(runFromPath);
    } catch (e) {
        // ignore
    }
};

const main = async () => {
    if (argv.help) {
        return displayHelp();
    }

    if (argv.version) {
        return displayVersion();
    }

    if (argv.filename) {
        withFileName = true;
    }

    if (argv['db-only']) {
        dbOnly = true;
    }

    if (argv.hash) {
        withHash = true;
    }

    if (argv['no-prompt']) {
        noPrompt = true;
    }

    // make sure we run from the correct dir so require()'s work
    setRunFromDir();

    const dupeFileInfo = await collectDuplicateInfo(argv['area-tag']);
    if (0 === dupeFileInfo.size) {
        console.info('No duplicates found.');
        return process.exit();
    }

    console.info(`${dupeFileInfo.size} duplicate entry(s) found.`);
    for (const [fileId, dupes] of dupeFileInfo) {
        await processDuplicateEntries(fileId, dupes);
    }
};

(async () => {
    try {
        await main();
    } catch (e) {
        console.error(`ERROR: ${e}`);
        process.exit(-1);
    }

    process.exit();
})();
